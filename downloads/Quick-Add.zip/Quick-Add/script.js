// public/js/script.js
jQuery(document).ready(function ($) {
    const productTemplate = $('#product-template').html();

    const addProduct = () => {
        const $template = $(productTemplate);

        // Populate grouped products dropdown
        const groupedSelect = $template.find('.grouped-products-wrapper select');
        if (Array.isArray(ipf_ajax.grouped_products)) {
            ipf_ajax.grouped_products.forEach(prod => {
                groupedSelect.append(`<option value="${prod.id}">${prod.title}</option>`);
            });
        }

        $('#product-container').append($template);
    };

    $('#add-product').on('click', function (e) {
        e.preventDefault();
        addProduct();
    });

    $(document).on('click', '.upload_image_button', function (e) {
        e.preventDefault();
        const button = $(this);
        const customUploader = wp.media({
            title: 'Select Image',
            button: { text: 'Use this image' },
            multiple: false
        });
        customUploader.on('select', function () {
            const attachment = customUploader.state().get('selection').first().toJSON();
            button.after(`<input type="hidden" name="product_image[]" value="${attachment.url}"><img src="${attachment.url}" style="max-width:100px; display:block; margin-top:5px;">`);
        });
        customUploader.open();
    });

    // Toggle sale scheduling fields
    $(document).on('change', '.schedule-sale-checkbox', function () {
        const container = $(this).closest('.product-block');
        if ($(this).is(':checked')) {
            container.find('.sale-fields').show();
        } else {
            container.find('.sale-fields').hide();
        }
    });

    // Add product attribute section
    $(document).on('click', '.add-attribute-btn', function () {
        const container = $(this).closest('.product-block');
        const index = $('.product-block').index(container);
        const attrHTML = `
            <div class="attribute-block">
                <label>Attribute Name <input type="text" name="attribute_name[${index}][]" /></label>
                <label>Attribute Values <input type="text" name="attribute_values[${index}][]" placeholder="e.g. Red|Blue|Green" /></label>
                <label><input type="checkbox" name="attribute_variation[${index}][]"> Used for Variations</label>
            </div>`;
        container.find('.attribute-container').append(attrHTML);
    });

    // Toggle variable product prompt
    $(document).on('change', 'select[name="product_type[]"]', function () {
        const container = $(this).closest('.product-block');
        const variationPrompt = container.find('.variation-choice');
        if ($(this).val() === 'variable') {
            variationPrompt.show();
        } else {
            variationPrompt.hide();
        }
    });

    $(document).on('change', 'select[name="product_type[]"]', function () {
        const $block = $(this).closest('.product-block');
        const type = $(this).val();

        $block.find('.external-url-wrapper').toggle(type === 'external');
        $block.find('.grouped-products-wrapper').toggle(type === 'grouped');
        $block.find('.variable-info').toggle(type === 'variable');
    });

    $('#product-form').on('submit', function (e) {
        e.preventDefault();
    
        const formData = $(this).serialize();
    
        $.post(ipf_ajax.ajax_url, formData + '&action=ipf_save_product&nonce=' + ipf_ajax.nonce, function (response) {
            if (response.success) {
                alert('Products submitted to WooCommerce successfully.');
                window.location.href = '/wp-admin/edit.php?post_type=product';

            } else {
                alert('Error submitting products.');
            }
        }).fail(function () {
            alert('Server error submitting products.');
        });
    });
    
});
