=== Quick Add ===
Contributors: robertcalvin
Tags: woocommerce, quick add, product creation, admin tools
Requires at least: 5.6
Tested up to: 6.8
Stable tag: 1.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Instantly create WooCommerce products from a custom admin screen. Upgrade to Pro for SEO and schema tools.

== Description ==

Quick Add lets you skip the bloated WooCommerce product editor and instantly create simple, grouped, and variable products using a lightning-fast admin form.

Features:

* Create products from a single form
* Upload images directly
* Set prices, sale dates, and attributes
* AJAX save, no reloads
* Compatible with any WooCommerce site

Want built-in SEO fields, product schema, and social preview meta? [Upgrade to Quick Add Pro](https://robert-calvin-dev.github.io/quickaddpro/).

== Frequently Asked Questions ==

= Is this compatible with the latest version of WooCommerce? =
Yes. Quick Add is tested against the latest stable release and WooCommerce 8.x

= Can I add variable products? =
Yes. You can add grouped and variable product types directly from the form.

= Does it include SEO fields? =
Not in the free version. You can unlock SEO and schema features by upgrading to Pro.

== Changelog ==

= 1.0 =
* Initial public release
* AJAX-powered product creation, WooCommerce integration

== Upgrade Notice ==

= 1.0 =
First release of Quick Add — upgrade to Pro for SEO fields, OG meta, and JSON-LD product schema support.

== A brief Markdown Example ==

[markdown syntax]: https://daringfireball.net/projects/markdown/syntax

Ordered list:
1. Add WooCommerce products instantly
2. Upload images and set prices
3. Upgrade to Pro for SEO fields

Unordered list:
* AJAX save
* No editor bloat
* Free and Pro versions available

Links:
Here's a link to [WordPress](https://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax].

> Asterisks for *emphasis*. Double it up for **strong**.

Backticks for code:
`<?php echo 'Quick Add'; ?>`
